package org.doit.ik.exception;

public class DuplicateIdException extends RuntimeException {

}
