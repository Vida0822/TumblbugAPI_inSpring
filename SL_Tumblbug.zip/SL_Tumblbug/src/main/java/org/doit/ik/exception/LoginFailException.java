package org.doit.ik.exception;

public class LoginFailException extends RuntimeException {

}
