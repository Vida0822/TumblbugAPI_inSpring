package org.doit.ik.mapper;

import org.doit.ik.domain.Project;

public interface ProjectMapper {

	// 프로젝트 얻어오기 
	Project getProject(String pro_cd);

} 
