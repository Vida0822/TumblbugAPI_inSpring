package org.doit.ik;

import org.springframework.stereotype.Controller;

@Controller
public class MemberController {

	/* 핸들러 함수들 구현하세요 ~ */
	
}
