package org.doit.ik.mapper;

public interface ManageMapper {

}
