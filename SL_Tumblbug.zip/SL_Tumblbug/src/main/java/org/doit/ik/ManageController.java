package org.doit.ik;

import org.springframework.stereotype.Controller;

@Controller
public class ManageController {

	/* 핸들러 함수들 구현하세요 ~ */ 
	
}
