package org.doit.ik.mapper;

public interface MemberMapper {

}
